package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.beans.StaffBean;


public class StaffDao {

	public static int save(StaffBean bean){
		int status=0;
		try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("insert into staff(name,email,password,education,department,subject,contact) values(?,?,?,?,?,?,?)");
			ps.setString(1,bean.getName());
			ps.setString(2,bean.getEmail());
			ps.setString(3,bean.getPassword());
			ps.setString(4,bean.getEducation());
			ps.setString(5,bean.getDepartment());
			ps.setString(6,bean.getSubject());
			ps.setString(7,bean.getContact());
			status=ps.executeUpdate();
			con.close();
		}catch(Exception ex){System.out.println(ex);}
		return status;
	}
	public static boolean validate(String email,String password){
		boolean status=false;
		try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("select * from staff where email=? and password=?");
			ps.setString(1,email);
			ps.setString(2,password);
			ResultSet rs=ps.executeQuery();
			status=rs.next();
			con.close();
		}catch(Exception ex){System.out.println(ex);}
		return status;
	}
	public static int update(StaffBean bean){
		int status=0;
		try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("update staff set name=?,email=?,password=?,education=?,department=?,subject=?,contact=? where id=?");
			ps.setString(1,bean.getName());
			ps.setString(2,bean.getEmail());
			ps.setString(3,bean.getPassword());
			ps.setString(4,bean.getEducation());
			ps.setString(5,bean.getDepartment());
			ps.setString(6,bean.getSubject());
			ps.setString(7,bean.getContact());
			ps.setInt(8,bean.getId());
			status=ps.executeUpdate();
			con.close();
		}catch(Exception ex){System.out.println(ex);}
		return status;
	}	

	public static int delete(int id){
		int status=0;
		try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("delete from staff where id=?");
			ps.setInt(1,id);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception ex){System.out.println(ex);}
		return status;
	}

	public static List<StaffBean> getAllRecords(){
		List<StaffBean> list=new ArrayList<StaffBean>();
		try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("select * from staff");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				StaffBean bean=new StaffBean();
				bean.setId(rs.getInt(1));
				bean.setName(rs.getString(2));
				bean.setEmail(rs.getString(3));
				bean.setPassword(rs.getString(4));
				bean.setEducation(rs.getString(5));
				bean.setDepartment(rs.getString(6));
				bean.setSubject(rs.getString(7));
				bean.setContact(rs.getString(8));
				list.add(bean);
			}
			con.close();
		}catch(Exception ex){System.out.println(ex);}
		
		return list;
	}

	public static StaffBean getRecordById(int id){
		StaffBean bean=new StaffBean();
		try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("select * from staff where id=?");
			ps.setInt(1,id);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				bean.setId(rs.getInt(1));
				bean.setName(rs.getString(2));
				bean.setEmail(rs.getString(3));
				bean.setPassword(rs.getString(4));
				bean.setEducation(rs.getString(5));
				bean.setDepartment(rs.getString(6));
				bean.setSubject(rs.getString(7));
				bean.setContact(rs.getString(8));
			}
			con.close();
		}catch(Exception ex){System.out.println(ex);}
		
		return bean;
	}
}
