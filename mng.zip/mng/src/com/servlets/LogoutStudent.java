package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LogoutStudent
 */
@WebServlet("/LogoutStudent")
public class LogoutStudent extends HttpServlet {
	
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.println("<!DOCTYPE html>");
		out.println("<html>");
		out.println("<head>");
		out.println("<title>Logout Accountant</title>");
		out.println("<link rel='stylesheet' href='resources/bootstrap.min.css'/>");
		out.println("<link rel='stylesheet' href='style.css'/>");
		out.println("</head>");
		out.println("<body>");

		int do_get = 1;
        PrintWriter pw = response.getWriter();
        HttpSession session = request.getSession(false);
        try
        {
            if(request.getParameter("action")!=null)
            {
                if(request.getParameter("action").equals("logout"))
                {

                    session = request.getSession(true);
                    session.setAttribute("name", "");
                    session.setAttribute("contact", "");
                    session.invalidate();
                   //  response.sendRedirect("index.html");
             		request.getRequestDispatcher("index.html").include(request, response);

                    return; 
                }
            }
            else
            if(session !=null)
                {
                 String username = null;
				if( (String)session.getAttribute(username)!=null)
                username = (String)session.getAttribute("name").toString();
                String password;
				if( (String)session.getAttribute("contact") !=null)
                 password =session.getAttribute("contact").toString();
                pw.write("not new-");
                service(request,response);
                }

        }
        catch(Exception ex)
        {
            pw.write("Error-"+ex.getMessage());
        } 

		
		out.println("</body>");
		out.println("</html>");
		
		out.close();
	}
		
		
	}


